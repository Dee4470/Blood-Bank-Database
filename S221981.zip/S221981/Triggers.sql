DELIMITER $$

CREATE TRIGGER Update_Staff
BEFORE UPDATE ON Staff
FOR EACH ROW
BEGIN
IF NEW.Staff_Gender != 'Male' OR 'Female' THEN
SET NEW.Staff_Gender = 'Unknown';
END IF;
END $$

DELIMITER ;


UPDATE Staff 
SET Staff_Gender = 'Unknown' WHERE StaffID = 501;

DROP TRIGGER Update_Staff;