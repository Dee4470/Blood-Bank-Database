#Populating the Blood_Bank Table with the blood_bank information
insert into Blood_Bank (BbankNO, Bbank_Address, Bbank_City) values (1, '55 Moose Drive', 'Egham');
insert into Blood_Bank (BbankNO, Bbank_Address, Bbank_City) values (2, '3413 Bowman Court','Feltham');
insert into Blood_Bank (BbankNO, Bbank_Address, Bbank_City) values (3, '96 Utah Lane','Woking');

SELECT * FROM Blood_Bank;

#Populating the department table with the department information
insert into Staff_Department (DepartmentNO,Department_Name) values (1,'Administrative');
insert into Staff_Department (DepartmentNO,Department_Name) values (2,'Laboratory');
insert into Staff_Department (DepartmentNO,Department_Name) values (3,'Nursing');


SELECT * FROM Department;

#Populating the staff table with the staff information
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('501', 'Rosaleen', 'McIlriach', 'Female', 'Nurse', 3);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('502', 'Ranique', 'Dubbin', 'Female', 'Manager', 1);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('503', 'Rani', 'Goodship', 'Female', 'Nurse', 3);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('504', 'Craige', 'Ungaretti', 'Male','Nurse', 3);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('505', 'Natassia', 'Bester', 'Female', 'Nurse', 3);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('506', 'Salmon', 'Middiff', 'Male', 'Supervisor', 1);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('507', 'Rasla', 'Canto', 'Female', 'Lab Scientist', 2);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('508', 'Francis', 'Jennison', 'Male', 'Lab Scientist', 2);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('509', 'Lyda', 'Priestner', 'Female', 'Nurse', 3);
insert into Staff (StaffID, Staff_Fname, Staff_Lname, Staff_Gender, Staff_Position, DepartmentNO) values ('510', 'Pate', 'Chinge', 'Female', 'Nurse', 3);

SELECT * FROM Staff;

#Populating the blood donor Table with the donor information
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2001', 'Torre', 'Soro', '806 Evergreen Circle', 'Male', '1980-08-24');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2002', 'Tine', 'Goor', '5 Mallory Road', 'Male', '1998-01-23');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2003', 'Joete', 'Mauchlen', '64779 Corry Place', 'Female', '1969-08-02');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2004', 'Rozalie', 'Itzcovich', '7 Veith Plaza', 'Female', '1961-04-02');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2005', 'Nicholas', 'Kapelhof', '1228 Clove Plaza', 'Female', '1953-11-03');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2006', 'Camellia', 'Maryman', '8647 Ridgeview Junction', 'Male', '1964-12-26');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2007', 'Bren', 'Solway', '3198 Holy Cross Avenue', 'Male', '1975-12-25');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2008', 'Mendel', 'Faichney', '212 Sundown Avenue', 'Female', '1966-09-27');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2009', 'Conrad', 'Micheau', '85871 Weeping Birch Avenue', 'Male', '1973-06-24');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2010', 'Abey', 'Cerith', '76 Colorado Way', 'Female', '1980-01-26');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2011', 'Worthington', 'Powner', '9789 Farwell Place', 'Male', '1969-10-19');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2012', 'Sapphire', 'Duggen', '087 Welch Pass', 'Female', '2003-01-21');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2013', 'Deeann', 'Eland', '16 Walton Pass', 'Female', '1998-12-11');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2014', 'Harlene', 'Tiernan', '3999 Sloan Junction', 'Male', '1978-01-13');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2015', 'Aguste', 'Iron', '6481 Farragut Crossing', 'Male', '1963-07-03');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2016', 'Bernarr', 'Walne', '53495 Veith Terrace', 'Male', '1970-10-12');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2017', 'Myca', 'Valero', '82 7th Trail', 'Male', '2005-06-17');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2018', 'Camella', 'Collip', '4 Memorial Hill', 'Female', '2006-10-08');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2019', 'Teodor', 'Hamerton', '73995 Ludington Center', 'Male', '1968-10-01');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2020', 'Russell', 'Brugden', '789 Hoard Pass', 'Male', '1988-12-03');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2021', 'Siward', 'Storah', '05194 Stoughton Terrace', 'Female', '2000-05-31');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2022', 'Nonie', 'Milmoe', '666 Declaration Park', 'Female', '2001-09-20');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2023', 'Jocko', 'Agass', '31 Fulton Circle', 'Male', '1963-09-03');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2024', 'Percy', 'Renforth', '7870 Prentice Pass', 'Male', '1977-09-21');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2025', 'Etti', 'Breach', '69151 Independence Way', 'Female', '2002-01-03');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2026', 'Samson', 'Boeter', '040 Moulton Alley', 'Female', '2006-12-11');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2027', 'Dag', 'Winscomb', '574 Mariners Cove Pass', 'Male', '1990-07-22');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2028', 'Cornall', 'Vala', '2 Anniversary Street', 'Male', '1951-09-23');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2029', 'Lazare', 'Berriman', '150 Eastwood Junction', 'Female', '1965-12-03');
insert into Blood_Donor (DonorID, Donor_Fname, Donor_Lname, Donor_Address, Donor_Gender, Donor_DOB) values ('2030', 'Chloe', 'Flisher', '8738 Monument Crossing', 'Male', '1973-11-27');

SELECT * FROM Blood_Donor;

#Populating the Patient table with the Patients' information
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('100', 'Josh', 'Morsley', '551 Melody Park', 'Male', '2004-07-08');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('101', 'Lyndsey', 'Rioch', '02840 Melrose Plaza', 'Female', '2013-03-08');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('102', 'Dierdre', 'Cromett', '87 Hooker Parkway', 'Female', '1987-06-06');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('103', 'Sally', 'Start', '674 Huxley Terrace', 'Female', '1988-03-06');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('104', 'Reggis', 'Wringe', '4949 Walton Court', 'Female', '2017-07-30');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('105', 'Devlen', 'Castellino', '032 Hallows Road', 'Female', '1969-11-09');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('106', 'Alasteir', 'Placido', '40671 Springview Avenue', 'Male', '2010-07-20');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('107', 'Dare', 'Gabbitis', '670 Loftsgordon Crossing', 'Male', '1959-04-12');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('108', 'Ty', 'Grinham', '652 Calypso Crossing', 'Female', '1979-11-18');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('109', 'Bella', 'Wallace', '6 Haas Alley', 'Male', '1946-08-26');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('110', 'Gwynne', 'Jaquet', '9 Meadow Valley Park', 'Male', '1992-01-15');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('111', 'Adriano', 'Abelson', '2 Northport Parkway', 'Female', '1962-08-29');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('112', 'Regen', 'McKennan', '0626 Pankratz Drive', 'Male', '2019-07-16');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('113', 'Grover', 'Reckhouse', '57305 Debs Trail', 'Male', '1999-12-25');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('114', 'Denice', 'Padula', '5 Summit Alley', 'Female', '1969-02-18');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('115', 'Marabel', 'MacQueen', '735 Lyons Avenue', 'Female', '1960-02-08');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('116', 'Arabele', 'Godridge', '4787 Raven Avenue', 'Male', '2006-04-13');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('117', 'Nellie', 'Skeels', '14 Moose Junction', 'Male', '1994-06-25');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('118', 'Orly', 'Kendred', '9 Thompson Avenue', 'Female', '1997-05-17');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('119', 'Petronia', 'Perschke', '21 Onsgard Circle', 'Male', '1981-07-25');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('120', 'Rachel', 'Semechik', '79 Sutteridge Street', 'Male', '1956-10-13');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('121', 'Gilda', 'Uren', '6 Oxford Pass', 'Male', '1975-01-27');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('122', 'Erroll', 'Isaak', '4 School Terrace', 'Male', '2007-05-22');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('123', 'Field', 'Beese', '25 Dahle Pass', 'Female', '1994-11-26');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('124', 'Ruggiero', 'Barten', '3 Corry Park', 'Female', '1986-07-25');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('125', 'Ikey', 'Titcom', '8602 Monica Street', 'Male', '1994-11-02');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('126', 'Alejandro', 'Iannelli', '5 Hansons Alley', 'Male', '2019-03-18');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('127', 'Bruno', 'Hassewell', '3251 Welch Place', 'Male', '1977-05-02');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('128', 'Kaylyn', 'Gilyatt', '31 Spaight Way', 'Female', '2017-06-30');
insert into Patient (PatientID, Patient_Fname, Patient_Lname, Patient_Address, Patient_Gender, Patient_DOB) values ('129', 'Ray', 'Fulop', '261 Lerdahl Avenue', 'Male', '1972-08-16');

SELECT * FROM Patient;



#Populating the blood donation table with the donation data
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (1, 2022, 501, 1, '2020-10-27');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (2, 2001, 505, 1, '2020-09-02');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (3, 2013, 502, 1, '2020-07-26');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (4, 2004, 504, 1, '2021-01-07');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (5, 2025, 510, 2, '2020-11-19');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (6, 2016, 506, 2, '2021-03-14');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (7, 2007, 507, 3, '2021-05-02');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (8, 2023, 508, 2, '2020-08-28');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (9, 2014,  503, 1, '2020-11-22');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (10, 2027, 509, 2, '2020-08-22');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (11, 2019, 505, 2, '2021-03-12');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (12, 2030, 501, 2, '2021-02-09');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (13, 2029, 504, 2, '2020-10-24');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (14, 2017, 510, 1, '2021-01-02');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (15, 2014, 506, 1, '2020-11-13');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (16, 2002, 504, 2, '2020-10-16');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (17, 2024, 508, 3, '2021-03-20');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (18, 2013, 505, 3, '2020-11-07');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (19, 2006, 502, 3, '2021-02-01');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (20, 2023, 510, 2, '2020-11-17');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (21, 2003, 510, 1, '2020-07-01');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (22, 2012, 506, 2, '2020-08-20');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (23, 2010, 501, 3, '2021-01-23');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (24, 2004, 504, 3, '2020-06-28');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (25, 2005, 509, 3, '2020-08-01');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (26, 2016, 502, 2, '2020-10-27');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (27, 2007, 501, 2, '2021-04-19');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (28, 2018, 502, 1, '2020-09-10');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (29, 2028, 504, 1, '2020-05-29');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (30, 2020, 503, 2, '2021-02-23');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (31, 2021, 507, 3, '2020-06-15');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (32, 2009, 508, 2, '2021-01-14');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (33, 2007, 503, 3, '2020-06-06');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (34, 2002, 507, 2, '2021-03-06');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (35, 2012, 505, 2, '2021-01-08');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (36, 2013, 506, 3, '2020-12-05');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (37, 2022, 501, 2, '2020-08-08');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (38, 2018, 508, 2, '2020-05-19');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (39, 2025, 509, 1, '2020-10-25');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (40, 2026, 501, 1, '2021-03-23');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (41, 2009, 509, 1, '2020-07-05');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (42, 2010, 503, 2, '2021-04-22');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (43, 2021, 502, 3, '2020-09-10');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (44, 2001, 510, 1, '2020-09-09');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (45, 2030, 504, 1, '2021-01-23');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (46, 2007, 501, 1, '2020-05-09');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (47, 2014, 505, 3, '2020-10-19');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (48, 2002, 508, 3, '2021-03-03');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (49, 2011, 509, 3, '2020-06-20');
insert into Blood_Donation (DonationNO, DonorID, StaffID, BbankNO, Donation_Date) values (50, 2023, 501, 3, '2020-06-06');

SELECT * FROM Blood_Donation;

#Populating the Blood Table with the blood information details
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (1, 100,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (2, 101,'AB');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (3, 102,'B');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (4, 103,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (5, 104,'O');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (6, 105,'B');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (7, 106,'B');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (8, 107,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (9, 108,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (10,109,'AB');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (11,110,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (12,111,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (13,112,'AB');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (14,113,'O');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (15,114,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (16,115,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (17,116,'AB');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (18,117,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (19,118,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (20,119,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (21,120,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (22,121,'O');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (23,122,'O');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (24,123,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (25,124,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (26,125,'AB');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (27,126,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (28,127,'O');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (29,128,'A');
insert into Patient_Blood (BloodID, PatientID,PBlood_Group) values (30,129,'A');

SELECT * FROM Patient_Blood;

insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (1, 2001,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (2, 2002,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (3, 2003,'O');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (4, 2004,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (5, 2005,'O');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (6, 2006,'B');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (7, 2007,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (8, 2008,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (9, 2009,'O');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (10,2010,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (11,2011,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (12,2012,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (13,2013,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (14,2014,'O');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (15,2015,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (16,2016,'B');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (17,2017,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (18,2018,'B');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (19,2019,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (20,2020,'B');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (21,2021,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (22,2022,'O');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (23,2023,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (24,2024,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (25,2025,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (26,2026,'AB');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (27,2027,'O');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (28,2028,'B');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (29,2029,'A');
insert into Donor_Blood (BloodID, DonorID,DBlood_Group) values (30,2030,'B');

SELECT * FROM Patient_Blood;

#Populating the disease table with the patients' medical history(disease information)
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (1, 'Gastroentritis', 100);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (2, 'Leukemia', 101);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (3, 'Pneumonia', 102);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (4, 'Colitis', 103);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (5, 'Jaundis', 104);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (6, 'Appendicitis', 105);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (7, 'Leukemia', 106);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (8, 'Fibroid', 107);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (9, 'Hydrocephallus', 108);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (10, 'Anemia', 109);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (11, 'Hermophilia', 110);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (12, 'Pneumonia', 111);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (13, 'Jaundis', 112);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (14, 'Gastroentritis', 113);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (15, 'Anemia', 114);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (16, 'Fibroid', 115);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (17, 'Colitis', 116);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (18, 'Appendicitis', 117);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (19, 'Nephritis', 118);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (20, 'Anemia', 119);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (21, 'PKD', 120);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (22, 'Hernia', 121);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (23, 'Fibroid', 122);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (24, 'Anemia', 123);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (25, 'PKD', 124);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (26, 'Nephritis', 125);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (27, 'Colitis', 126);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (28, 'Jaundis', 127);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (29, 'Pneumonia', 128);
insert into Disease (DiseaseNO, Disease_Name, PatientID) values (30, 'Leukemia', 129);

SELECT * FROM Disease;