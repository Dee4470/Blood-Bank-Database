#This script shows the view of patient information the nursing department member have access to
CREATE VIEW Patients_Information 
AS SELECT P.PatientID,P.Patient_Fname,P.Patient_Lname,P.Patient_Gender, P.Patient_DOB, P.Patient_Address,
PB.PBLood_Group, D.Disease_Name
FROM Patient AS P INNER JOIN Patient_Blood AS PB ON P.PatientID = PB.PatientID
INNER JOIN Disease AS D ON D.PatientID = P.PatientID;

SELECT * FROM Patients_Information ;

#This script gives the administrative department the view of the staff information and their respective departments
CREATE VIEW Staff_Information 
AS SELECT S.StaffID, S.Staff_Fname, S.Staff_Lname,
S.Staff_Gender,S.Staff_Position, SD.Department_Name
FROM Staff AS S JOIN Staff_Department AS SD 
ON S.DepartmentNO = SD.DepartmentNO;

SELECT * FROM Staff_Information;

#This script gives the Laboratory department the view of the blood donors' information
CREATE VIEW Donor_Information AS SELECT BD.DonorID,BD.Donor_Fname, BD.Donor_Lname,
BD.Donor_Gender, BD.Donor_Address, BD.Donor_DOB, DB.DBlood_Group 
FROM Blood_Donor AS BD INNER JOIN Donor_Blood AS DB
ON BD.DonorID = DB.DonorID;

SELECT * FROM Donor_Information;
