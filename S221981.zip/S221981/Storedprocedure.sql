#This stored procedure retrieves donors'name and blood information
CREATE PROCEDURE GetAllDonors()
SELECT Donor_Fname, Donor_Lname, DBlood_Group
FROM Blood_Donor AS BD 
JOIN Donor_Blood AS DB ON BD.DonorID=DB.DonorID;

CALL GetAllDonors;

#This stored procedure retrieves patientd'name,blood information and their medical history(disease)
CREATE PROCEDURE GetAllPatients()
SELECT Patient_Fname, Patient_Lname, PBlood_Group, Disease_Name
FROM Patient AS P 
JOIN Patient_Blood AS PB ON PB.PatientID=P.PatientID
JOIN Disease AS D ON D.PatientID=P.PatientID;

CALL GetAllPatients;

#This stored procedure retrieves staff's name and department they belong
CREATE PROCEDURE SelectAllStaff()
SELECT Staff_Fname,Staff_Lname,Department_Name
FROM Staff AS S
JOIN Staff_Department AS SD ON S.DepartmentNO=SD.DepartmentNO;

CALL SelectAllStaff;