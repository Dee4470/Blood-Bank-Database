#Retrieving information about staff working at Department 3
SELECT S.Staff_Fname, S.Staff_Lname, S.Staff_Position, SD.Department_Name 
FROM Staff_Department AS SD
	JOIN Staff AS S ON S.DepartmentNO = SD.DepartmentNO
    WHERE SD.DepartmentNO = 3;

#Retrieving names,address and blood group of blood donors that donated blood within some certain date range
SELECT BD.Donor_Fname, BD.Donor_Lname, BD.Donor_Address, DB.DBlood_Group, BL.Donation_Date
FROM Blood_Donor AS BD
    JOIN Blood_Donation AS BL ON BD.DonorID = BL.DonorID
    JOIN Donor_Blood AS DB ON DB.DonorID = BL.DonorID
	WHERE Donation_Date BETWEEN '2021-01-08' AND '2021-03-12';

#The script below retrieves all the information of staffs that are female and their departments
SELECT StaffID, Staff_Fname, Staff_Lname, Staff_Position, Staff_Gender, Department_Name
FROM Staff AS S 
JOIN Staff_Department AS SD ON S.DepartmentNO=SD.DepartmentNO
WHERE Staff_Gender = 'Female'
ORDER BY StaffID ASC;


#The script below retrives information about Patients not suffering from Anemia
SELECT P.Patient_Fname, P.Patient_Lname, P.Patient_Address, P.Patient_Gender, Disease_Name
FROM Patient AS P 
JOIN Disease AS D ON D.PatientID = P.PatientID
WHERE Disease_Name != 'Anemia';


#Retrieving Patient details where Patient's first name is like "Gro" 
#Used when staff can't spell the Patient name
SELECT * FROM Patient WHERE Patient_Fname LIKE "Gro%";

#Retrieving Patient details where Patient's DOB falls within a specified Age range 
#This is used to keep track of the older patients information
SELECT Patient_Fname, Patient_Lname, Patient_Address, Patient_DOB 
FROM Patient
WHERE Patient_DOB BETWEEN '1946-08-26' AND '1960-02-08' 
ORDER BY Patient_DOB ASC;


#Retrieving information about blood donors with blood group O 
#This is used to keep track of donors with the universal donor blood type
SELECT Donor_Fname, Donor_Lname, Donor_Gender
FROM Blood_Donor
WHERE DonorID IN (SELECT DonorID 
                                    FROM Donor_Blood 
                                    WHERE DBlood_Group = 'O'); 

#Retrieving blood group information for patient with the blood groupS that is not (A or B)
SELECT P.Patient_Fname, P.Patient_Lname, PB.PBlood_Group
FROM Patient_Blood AS PB
INNER JOIN Patient AS P ON PB.PatientID = P.PatientID
WHERE PB.PBlood_Group != 'A' AND PB.PBlood_Group != 'AB';

#Retrieving the name of blood donors and the staff who attended to the donors on a specific date 
#information retrieved must include the blood bank address
SELECT BD.Donor_Fname, BD.Donor_Lname, S.Staff_Fname, S.Staff_Lname, BL.Donation_Date, BB.Bbank_Address
FROM Blood_Donor AS BD
   JOIN Blood_Donation AS BL ON BD.DonorID = BL.DonorID
   JOIN Blood_Bank AS BB ON BB.BbankNO = BL.BbankNO
   JOIN Staff AS S ON S.StaffID = BL.StaffID
WHERE BL.Donation_Date = '2021-01-08' OR BL.Donation_Date= '2021-03-03';
 
 




