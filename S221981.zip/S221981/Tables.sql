CREATE DATABASE BLOOD_BANK;
USE BLOOD_BANK;

#Creating a table that stores the Blood bank information
CREATE TABLE Blood_Bank(
BbankNO int,
Bbank_Address varchar (35),
Bbank_City varchar (35),
PRIMARY KEY (BbankNO)
);
SELECT * FROM Blood_Bank;

#Creating a table that  stores information about departments in the blood bank
CREATE TABLE Staff_Department(
DepartmentNO Int,
Department_Name varchar (35),
PRIMARY KEY (DepartmentNO)
);
SELECT * FROM Staff_Department;

#Creating a table that stores the Blood bank employees information
CREATE TABLE Staff(
StaffID int,
Staff_Fname varchar (35),
Staff_Lname varchar (35),
Staff_Gender char (10),
Staff_Position varchar(35),
DepartmentNO int,
PRIMARY KEY(StaffID),
FOREIGN KEY (DepartmentNO) REFERENCES Staff_Department (DepartmentNO)
);
SELECT * FROM Staff;

#Creating a table that stores the Blood Donor information
CREATE TABLE Blood_Donor(
DonorID int,
Donor_Fname varchar (35),
Donor_Lname varchar (35),
Donor_Address varchar (35),
Donor_Gender char (10),
Donor_DOB date,
PRIMARY KEY(DonorID)
);
SELECT * FROM Blood_Donor;

#Creating a table that stores the Patient information
CREATE TABLE Patient(
PatientID int,
Patient_Fname varchar (35),
Patient_Lname varchar (35),
Patient_Address varchar (35),
Patient_Gender char (10),
Patient_DOB date,
PRIMARY KEY(PatientID)
);
SELECT * FROM Patient;

#Creating a table that stores the Blood donation information
CREATE TABLE Blood_Donation(
DonationNO int,
DonorID int,
StaffID int,
BbankNO int,
Donation_Date date,
PRIMARY KEY(DonationNO),
FOREIGN KEY(DonorID) REFERENCES Blood_Donor(DonorID),
FOREIGN KEY(StaffID) REFERENCES Staff(StaffID),
FOREIGN KEY(BbankNO) REFERENCES Blood_Bank(BbankNO)
);
SELECT * FROM Blood_Donation;

#Creating a table that stores the donors and pateints' blood information
CREATE TABLE Patient_Blood(
BloodID int,
PatientID int,
PBlood_Group char(5),
PRIMARY KEY (BloodID),
FOREIGN KEY (PatientID) REFERENCES Patient (PatientID)
);
SELECT * FROM Patient_Blood;

CREATE TABLE Donor_Blood(
BloodID int,
DonorID int,
DBlood_Group char(5),
PRIMARY KEY (BloodID),
FOREIGN KEY (DonorID) REFERENCES Blood_Donor (DonorID)
);
SELECT * FROM Donor_Blood;

#Creating a table that stores the information about patients' medical history(disease information)
CREATE TABLE Disease(
DiseaseNO int,
PatientID int,
Disease_Name varchar(35),
PRIMARY KEY(DiseaseNO),
FOREIGN KEY (PatientID) REFERENCES Patient (PatientID)
);
SELECT * FROM Disease;




