-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: localhost    Database: BLOOD_BANK
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Blood_Donor`
--

DROP TABLE IF EXISTS `Blood_Donor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Blood_Donor` (
  `DonorID` int NOT NULL,
  `Donor_Fname` varchar(35) DEFAULT NULL,
  `Donor_Lname` varchar(35) DEFAULT NULL,
  `Donor_Address` varchar(35) DEFAULT NULL,
  `Donor_Gender` char(10) DEFAULT NULL,
  `Donor_DOB` date DEFAULT NULL,
  PRIMARY KEY (`DonorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Blood_Donor`
--

LOCK TABLES `Blood_Donor` WRITE;
/*!40000 ALTER TABLE `Blood_Donor` DISABLE KEYS */;
INSERT INTO `Blood_Donor` VALUES (2001,'Torre','Soro','806 Evergreen Circle','Male','1980-08-24'),(2002,'Tine','Goor','5 Mallory Road','Male','1998-01-23'),(2003,'Joete','Mauchlen','64779 Corry Place','Female','1969-08-02'),(2004,'Rozalie','Itzcovich','7 Veith Plaza','Female','1961-04-02'),(2005,'Nicholas','Kapelhof','1228 Clove Plaza','Female','1953-11-03'),(2006,'Camellia','Maryman','8647 Ridgeview Junction','Male','1964-12-26'),(2007,'Bren','Solway','3198 Holy Cross Avenue','Male','1975-12-25'),(2008,'Mendel','Faichney','212 Sundown Avenue','Female','1966-09-27'),(2009,'Conrad','Micheau','85871 Weeping Birch Avenue','Male','1973-06-24'),(2010,'Abey','Cerith','76 Colorado Way','Female','1980-01-26'),(2011,'Worthington','Powner','9789 Farwell Place','Male','1969-10-19'),(2012,'Sapphire','Duggen','087 Welch Pass','Female','2003-01-21'),(2013,'Deeann','Eland','16 Walton Pass','Female','1998-12-11'),(2014,'Harlene','Tiernan','3999 Sloan Junction','Male','1978-01-13'),(2015,'Aguste','Iron','6481 Farragut Crossing','Male','1963-07-03'),(2016,'Bernarr','Walne','53495 Veith Terrace','Male','1970-10-12'),(2017,'Myca','Valero','82 7th Trail','Male','2005-06-17'),(2018,'Camella','Collip','4 Memorial Hill','Female','2006-10-08'),(2019,'Teodor','Hamerton','73995 Ludington Center','Male','1968-10-01'),(2020,'Russell','Brugden','789 Hoard Pass','Male','1988-12-03'),(2021,'Siward','Storah','05194 Stoughton Terrace','Female','2000-05-31'),(2022,'Nonie','Milmoe','666 Declaration Park','Female','2001-09-20'),(2023,'Jocko','Agass','31 Fulton Circle','Male','1963-09-03'),(2024,'Percy','Renforth','7870 Prentice Pass','Male','1977-09-21'),(2025,'Etti','Breach','69151 Independence Way','Female','2002-01-03'),(2026,'Samson','Boeter','040 Moulton Alley','Female','2006-12-11'),(2027,'Dag','Winscomb','574 Mariners Cove Pass','Male','1990-07-22'),(2028,'Cornall','Vala','2 Anniversary Street','Male','1951-09-23'),(2029,'Lazare','Berriman','150 Eastwood Junction','Female','1965-12-03'),(2030,'Chloe','Flisher','8738 Monument Crossing','Male','1973-11-27');
/*!40000 ALTER TABLE `Blood_Donor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-26  9:30:18
