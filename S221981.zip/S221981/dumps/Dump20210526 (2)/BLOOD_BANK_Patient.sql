-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: localhost    Database: BLOOD_BANK
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Patient`
--

DROP TABLE IF EXISTS `Patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Patient` (
  `PatientID` int NOT NULL,
  `Patient_Fname` varchar(35) DEFAULT NULL,
  `Patient_Lname` varchar(35) DEFAULT NULL,
  `Patient_Address` varchar(35) DEFAULT NULL,
  `Patient_Gender` char(10) DEFAULT NULL,
  `Patient_DOB` date DEFAULT NULL,
  PRIMARY KEY (`PatientID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Patient`
--

LOCK TABLES `Patient` WRITE;
/*!40000 ALTER TABLE `Patient` DISABLE KEYS */;
INSERT INTO `Patient` VALUES (100,'Josh','Morsley','551 Melody Park','Male','2004-07-08'),(101,'Lyndsey','Rioch','02840 Melrose Plaza','Female','2013-03-08'),(102,'Dierdre','Cromett','87 Hooker Parkway','Female','1987-06-06'),(103,'Sally','Start','674 Huxley Terrace','Female','1988-03-06'),(104,'Reggis','Wringe','4949 Walton Court','Female','2017-07-30'),(105,'Devlen','Castellino','032 Hallows Road','Female','1969-11-09'),(106,'Alasteir','Placido','40671 Springview Avenue','Male','2010-07-20'),(107,'Dare','Gabbitis','670 Loftsgordon Crossing','Male','1959-04-12'),(108,'Ty','Grinham','652 Calypso Crossing','Female','1979-11-18'),(109,'Bella','Wallace','6 Haas Alley','Male','1946-08-26'),(110,'Gwynne','Jaquet','9 Meadow Valley Park','Male','1992-01-15'),(111,'Adriano','Abelson','2 Northport Parkway','Female','1962-08-29'),(112,'Regen','McKennan','0626 Pankratz Drive','Male','2019-07-16'),(113,'Grover','Reckhouse','57305 Debs Trail','Male','1999-12-25'),(114,'Denice','Padula','5 Summit Alley','Female','1969-02-18'),(115,'Marabel','MacQueen','735 Lyons Avenue','Female','1960-02-08'),(116,'Arabele','Godridge','4787 Raven Avenue','Male','2006-04-13'),(117,'Nellie','Skeels','14 Moose Junction','Male','1994-06-25'),(118,'Orly','Kendred','9 Thompson Avenue','Female','1997-05-17'),(119,'Petronia','Perschke','21 Onsgard Circle','Male','1981-07-25'),(120,'Rachel','Semechik','79 Sutteridge Street','Male','1956-10-13'),(121,'Gilda','Uren','6 Oxford Pass','Male','1975-01-27'),(122,'Erroll','Isaak','4 School Terrace','Male','2007-05-22'),(123,'Field','Beese','25 Dahle Pass','Female','1994-11-26'),(124,'Ruggiero','Barten','3 Corry Park','Female','1986-07-25'),(125,'Ikey','Titcom','8602 Monica Street','Male','1994-11-02'),(126,'Alejandro','Iannelli','5 Hansons Alley','Male','2019-03-18'),(127,'Bruno','Hassewell','3251 Welch Place','Male','1977-05-02'),(128,'Kaylyn','Gilyatt','31 Spaight Way','Female','2017-06-30'),(129,'Ray','Fulop','261 Lerdahl Avenue','Male','1972-08-16');
/*!40000 ALTER TABLE `Patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `Patient_Insert` AFTER INSERT ON `patient` FOR EACH ROW BEGIN
Insert into Patient Values (New.Patient_Lname);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-26  9:30:17
