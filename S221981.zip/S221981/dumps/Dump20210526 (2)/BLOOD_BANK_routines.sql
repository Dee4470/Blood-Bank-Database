-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: localhost    Database: BLOOD_BANK
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `patients_information`
--

DROP TABLE IF EXISTS `patients_information`;
/*!50001 DROP VIEW IF EXISTS `patients_information`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `patients_information` AS SELECT 
 1 AS `PatientID`,
 1 AS `Patient_Fname`,
 1 AS `Patient_Lname`,
 1 AS `Patient_Gender`,
 1 AS `Patient_DOB`,
 1 AS `Patient_Address`,
 1 AS `PBLood_Group`,
 1 AS `Disease_Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `staff_information`
--

DROP TABLE IF EXISTS `staff_information`;
/*!50001 DROP VIEW IF EXISTS `staff_information`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `staff_information` AS SELECT 
 1 AS `StaffID`,
 1 AS `Staff_Fname`,
 1 AS `Staff_Lname`,
 1 AS `Staff_Gender`,
 1 AS `Staff_Position`,
 1 AS `Department_Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `donor_information`
--

DROP TABLE IF EXISTS `donor_information`;
/*!50001 DROP VIEW IF EXISTS `donor_information`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `donor_information` AS SELECT 
 1 AS `DonorID`,
 1 AS `Donor_Fname`,
 1 AS `Donor_Lname`,
 1 AS `Donor_Gender`,
 1 AS `Donor_Address`,
 1 AS `Donor_DOB`,
 1 AS `DBlood_Group`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `patients_information`
--

/*!50001 DROP VIEW IF EXISTS `patients_information`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `patients_information` AS select `P`.`PatientID` AS `PatientID`,`P`.`Patient_Fname` AS `Patient_Fname`,`P`.`Patient_Lname` AS `Patient_Lname`,`P`.`Patient_Gender` AS `Patient_Gender`,`P`.`Patient_DOB` AS `Patient_DOB`,`P`.`Patient_Address` AS `Patient_Address`,`PB`.`PBlood_Group` AS `PBLood_Group`,`D`.`Disease_Name` AS `Disease_Name` from ((`patient` `P` join `patient_blood` `PB` on((`P`.`PatientID` = `PB`.`PatientID`))) join `disease` `D` on((`D`.`PatientID` = `P`.`PatientID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `staff_information`
--

/*!50001 DROP VIEW IF EXISTS `staff_information`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `staff_information` AS select `S`.`StaffID` AS `StaffID`,`S`.`Staff_Fname` AS `Staff_Fname`,`S`.`Staff_Lname` AS `Staff_Lname`,`S`.`Staff_Gender` AS `Staff_Gender`,`S`.`Staff_Position` AS `Staff_Position`,`SD`.`Department_Name` AS `Department_Name` from (`staff` `S` join `staff_department` `SD` on((`S`.`DepartmentNO` = `SD`.`DepartmentNO`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `donor_information`
--

/*!50001 DROP VIEW IF EXISTS `donor_information`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `donor_information` AS select `BD`.`DonorID` AS `DonorID`,`BD`.`Donor_Fname` AS `Donor_Fname`,`BD`.`Donor_Lname` AS `Donor_Lname`,`BD`.`Donor_Gender` AS `Donor_Gender`,`BD`.`Donor_Address` AS `Donor_Address`,`BD`.`Donor_DOB` AS `Donor_DOB`,`DB`.`DBlood_Group` AS `DBlood_Group` from (`blood_donor` `BD` join `donor_blood` `DB` on((`BD`.`DonorID` = `DB`.`DonorID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'BLOOD_BANK'
--

--
-- Dumping routines for database 'BLOOD_BANK'
--
/*!50003 DROP PROCEDURE IF EXISTS `GetAllDonors` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllDonors`()
SELECT Donor_Fname, Donor_Lname, DBlood_Group
FROM Blood_Donor AS BD 
JOIN Donor_Blood AS DB ON BD.DonorID=DB.DonorID ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllPatients` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllPatients`()
SELECT Patient_Fname, Patient_Lname, PBlood_Group, Disease_Name
FROM Patient AS P 
JOIN Patient_Blood AS PB ON PB.PatientID=P.PatientID
JOIN Disease AS D ON D.PatientID=P.PatientID ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectAllStaff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectAllStaff`()
SELECT Staff_Fname,Staff_Lname,Department_Name
FROM Staff AS S
JOIN Staff_Department AS SD ON S.DepartmentNO=SD.DepartmentNO ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-26  9:30:20
