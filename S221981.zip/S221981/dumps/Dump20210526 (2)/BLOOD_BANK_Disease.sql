-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: localhost    Database: BLOOD_BANK
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Disease`
--

DROP TABLE IF EXISTS `Disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Disease` (
  `DiseaseNO` int NOT NULL,
  `PatientID` int DEFAULT NULL,
  `Disease_Name` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`DiseaseNO`),
  KEY `PatientID` (`PatientID`),
  CONSTRAINT `disease_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `Patient` (`PatientID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Disease`
--

LOCK TABLES `Disease` WRITE;
/*!40000 ALTER TABLE `Disease` DISABLE KEYS */;
INSERT INTO `Disease` VALUES (1,100,'Gastroentritis'),(2,101,'Leukemia'),(3,102,'Pneumonia'),(4,103,'Colitis'),(5,104,'Jaundis'),(6,105,'Appendicitis'),(7,106,'Leukemia'),(8,107,'Fibroid'),(9,108,'Hydrocephallus'),(10,109,'Anemia'),(11,110,'Hermophilia'),(12,111,'Pneumonia'),(13,112,'Jaundis'),(14,113,'Gastroentritis'),(15,114,'Anemia'),(16,115,'Fibroid'),(17,116,'Colitis'),(18,117,'Appendicitis'),(19,118,'Nephritis'),(20,119,'Anemia'),(21,120,'PKD'),(22,121,'Hernia'),(23,122,'Fibroid'),(24,123,'Anemia'),(25,124,'PKD'),(26,125,'Nephritis'),(27,126,'Colitis'),(28,127,'Jaundis'),(29,128,'Pneumonia'),(30,129,'Leukemia');
/*!40000 ALTER TABLE `Disease` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-26  9:30:17
